package com.example.chessarrows

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** adopt = accept the new position as the baseline; whiteToMove = null means "turn unclear". */
class Turn(val adopt: Boolean, val whiteToMove: Boolean?)

/**
 * Reads a chess board from a screen frame without any image library.
 *
 * Self-calibrating: when you calibrate on the starting position it learns what your pieces look
 * like (as silhouettes, so square colour doesn't matter), whether you're White or Black, and how
 * noisy empty squares are (wood grain etc.) so it can pick its own colour threshold.
 */
class BoardReader {
    companion object {
        const val START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
    }

    var board = Rect()
    var flipped = false          // true when Black is at the bottom of the screen
    var calibrated = false

    private val N = 28           // samples per square side
    private val LO = 3
    private val HI = 24          // central 22x22 samples are used for the silhouette
    private val SIDE = HI - LO + 1
    private val G = 11           // 22 -> 11 after 2x2 averaging

    private var thr = 50         // colour distance that counts as "piece pixel" (chosen at calibration)

    private class Feat(val fill: Float, val lum: Float, val grid: FloatArray)

    private val templates = HashMap<Char, FloatArray>()
    private var emptyFill = 0.15f   // below this a square is empty
    private var lowFill = 0.25f     // below this a blob must also look like a piece, or it's ignored
    private var maxD = 25f          // worst acceptable silhouette distance for such a small blob
    private var lumSplit = 128f

    private fun feat(bmp: Bitmap, row: Int, col: Int): Feat {
        val sw = board.width() / 8f
        val sh = board.height() / 8f
        val ox = board.left + col * sw
        val oy = board.top + row * sh
        val px = Array(N) { IntArray(N) }
        for (gy in 0 until N) for (gx in 0 until N) {
            val x = (ox + (gx + 0.5f) * sw / N).toInt().coerceIn(0, bmp.width - 1)
            val y = (oy + (gy + 0.5f) * sh / N).toInt().coerceIn(0, bmp.height - 1)
            px[gy][gx] = bmp.getPixel(x, y)
        }
        // Background = per-channel median of the outer ring of the square.
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        for (gy in 0 until N) for (gx in 0 until N) {
            if (gx < 2 || gy < 2 || gx >= N - 2 || gy >= N - 2) {
                val p = px[gy][gx]
                rs.add((p shr 16) and 255); gs.add((p shr 8) and 255); bs.add(p and 255)
            }
        }
        rs.sort(); gs.sort(); bs.sort()
        val br = rs[rs.size / 2]; val bgc = gs[gs.size / 2]; val bb = bs[bs.size / 2]

        val mask = Array(SIDE) { BooleanArray(SIDE) }
        val lumA = Array(SIDE) { FloatArray(SIDE) }
        for (gy in LO..HI) for (gx in LO..HI) {
            if (col == 0 && gx < 8 && gy < 9) continue       // rank number printed in the corner
            if (row == 7 && gx >= 20 && gy >= 19) continue   // file letter printed in the corner
            val p = px[gy][gx]
            val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            if (abs(r - br) + abs(g - bgc) + abs(b - bb) > thr) {
                mask[gy - LO][gx - LO] = true
                lumA[gy - LO][gx - LO] = 0.299f * r + 0.587f * g + 0.114f * b
            }
        }
        // Drop isolated specks (wood grain, compression noise): keep pixels with >= 3 of 8 neighbours set.
        val raw = Array(SIDE) { FloatArray(SIDE) }
        var count = 0
        var lumSum = 0f
        for (y in 0 until SIDE) for (x in 0 until SIDE) {
            if (!mask[y][x]) continue
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until SIDE && xx in 0 until SIDE && mask[yy][xx]) n++
            }
            if (n >= 3) { raw[y][x] = 1f; count++; lumSum += lumA[y][x] }
        }
        val grid = FloatArray(G * G)
        for (cy in 0 until G) for (cx in 0 until G) {
            grid[cy * G + cx] = (raw[2 * cy][2 * cx] + raw[2 * cy][2 * cx + 1] +
                raw[2 * cy + 1][2 * cx] + raw[2 * cy + 1][2 * cx + 1]) / 4f
        }
        return Feat(count / (SIDE * SIDE).toFloat(), if (count > 0) lumSum / count else 0f, grid)
    }

    private fun lumAt(bmp: Bitmap, x: Int, y: Int): Float {
        val p = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
        return 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
    }

    /**
     * Taps are never exact. This snaps the tapped rectangle onto the real board by finding where the
     * light/dark square edges are (strong brightness jumps) and picking the grid that lines up best.
     */
    private fun refine(bmp: Bitmap, r: Rect): Rect {
        val range = 45; val sizeRange = 70; val d = 3
        val l0 = r.left; val t0 = r.top; val s0 = r.width()
        val sq0 = s0 / 8f

        // Vertical edges (between files), measured on the empty middle ranks.
        val ys = ArrayList<Int>()
        for (row in 0..3) for (j in 0..5) ys.add((t0 + (row + 2) * sq0 + (j + 0.5f) * sq0 / 6).toInt())
        val xLo = l0 - range - 10
        val xHi = l0 + s0 + range + sizeRange + 10
        val ex = FloatArray(xHi - xLo + 1)
        for (x in xLo..xHi) {
            var sum = 0f
            for (y in ys) sum += abs(lumAt(bmp, x + d, y) - lumAt(bmp, x - d, y))
            ex[x - xLo] = sum / ys.size
        }
        // Horizontal edges (between ranks), measured across all columns.
        val xs = ArrayList<Int>()
        for (c in 0..7) for (i in 0..7) xs.add((l0 + (c + 0.5f) * sq0 + (i - 3.5f) * sq0 / 10).toInt())
        val yLo = t0 - range - 10
        val yHi = t0 + s0 + range + sizeRange + 10
        val ey = FloatArray(yHi - yLo + 1)
        for (y in yLo..yHi) {
            var sum = 0f
            for (x in xs) sum += abs(lumAt(bmp, x, y + d) - lumAt(bmp, x, y - d))
            ey[y - yLo] = sum / xs.size
        }

        var bestScore = -1f; var bestL = l0; var bestT = t0; var bestS = s0
        for (s in (s0 - sizeRange)..(s0 + sizeRange)) {
            val sq = s / 8f
            var bl = -1f; var bestLx = l0
            for (l in (l0 - range)..(l0 + range)) {
                var sum = 0f
                for (c in 1..7) { val i = (l + c * sq).roundToInt() - xLo; if (i in ex.indices) sum += ex[i] }
                if (sum > bl) { bl = sum; bestLx = l }
            }
            var bt = -1f; var bestTy = t0
            for (t in (t0 - range)..(t0 + range)) {
                var sum = 0f
                for (c in 1..7) { val i = (t + c * sq).roundToInt() - yLo; if (i in ey.indices) sum += ey[i] }
                if (sum > bt) { bt = sum; bestTy = t }
            }
            if (bl + bt > bestScore) { bestScore = bl + bt; bestL = bestLx; bestT = bestTy; bestS = s }
        }
        return Rect(bestL, bestT, bestL + bestS, bestT + bestS)
    }

    private fun rowLum(row: Array<Feat>) = row.map { it.lum }.average().toFloat()

    private fun dist(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        for (i in a.indices) d += abs(a[i] - b[i])
        return d
    }

    /** Call on the starting position. Returns null on success, otherwise an error message. */
    fun calibrate(bmp: Bitmap, rect: Rect): String? {
        board = refine(bmp, rect)

        // Pick the colour threshold: the lowest value at which the empty middle squares look empty.
        var chosen = 100
        var t = 45
        while (t <= 100) {
            thr = t
            var worst = 0f
            for (r in 2..5) for (c in 0..7) worst = max(worst, feat(bmp, r, c).fill)
            if (worst <= 0.02f) { chosen = min(t + 5, 100); break }
            t += 5
        }
        thr = chosen

        val f = Array(8) { r -> Array(8) { c -> feat(bmp, r, c) } }
        for (r in 2..5) for (c in 0..7) if (f[r][c].fill > 0.04f)
            return "Middle squares aren't empty. Calibrate on a fresh game's starting position."
        for (r in listOf(0, 1, 6, 7)) for (c in 0..7) if (f[r][c].fill < 0.1f)
            return "Couldn't see the start pieces. Re-tap the board's two corners."

        flipped = rowLum(f[7]) < rowLum(f[0])   // darker pieces on the bottom row => Black at bottom

        val back = "RNBQKBNR"
        fun startPiece(r: Int, c: Int): Char? {
            val file = if (!flipped) c else 7 - c
            val rank = if (!flipped) 8 - r else r + 1
            return when (rank) {
                1 -> back[file]
                2 -> 'P'
                7 -> 'p'
                8 -> back[file].lowercaseChar()
                else -> null
            }
        }

        val sums = HashMap<Char, FloatArray>()
        val cnt = HashMap<Char, Int>()
        var wLum = 0f; var wN = 0; var bLum = 0f; var bN = 0; var pawnFill = 0f; var pawnN = 0
        for (r in 0..7) for (c in 0..7) {
            val p = startPiece(r, c) ?: continue
            val ft = f[r][c]
            val acc = sums.getOrPut(p) { FloatArray(G * G) }
            for (i in acc.indices) acc[i] += ft.grid[i]
            cnt[p] = (cnt[p] ?: 0) + 1
            if (p.isUpperCase()) { wLum += ft.lum; wN++ } else { bLum += ft.lum; bN++ }
            if (p == 'P' || p == 'p') { pawnFill += ft.fill; pawnN++ }
        }
        templates.clear()
        for ((p, acc) in sums) {
            val n = cnt[p]!!.toFloat()
            templates[p] = FloatArray(acc.size) { acc[it] / n }
        }
        lumSplit = (wLum / wN + bLum / bN) / 2f
        emptyFill = 0.5f * pawnFill / pawnN
        lowFill = 0.7f * pawnFill / pawnN
        var maxSelf = 0f
        for (r in 0..7) for (c in 0..7) {
            val p = startPiece(r, c) ?: continue
            maxSelf = max(maxSelf, dist(templates[p]!!, f[r][c].grid))
        }
        maxD = max(18f, 2.4f * maxSelf)
        calibrated = true
        return null
    }

    /** Piece placement (first FEN field) or null if the frame doesn't look like a sane position. */
    fun read(bmp: Bitmap): String? {
        val grid = Array(8) { CharArray(8) { ' ' } }
        for (r in 0..7) for (c in 0..7) {
            val ft = feat(bmp, r, c)
            if (ft.fill < emptyFill) continue
            val white = ft.lum > lumSplit
            var best = '?'
            var bestD = Float.MAX_VALUE
            for ((p, t) in templates) {
                if (p.isUpperCase() != white) continue
                val d = dist(t, ft.grid)
                if (d < bestD) { bestD = d; best = p }
            }
            if (ft.fill < lowFill && bestD > maxD) continue   // small blob that isn't a piece (move dot)
            grid[r][c] = best
        }

        val sb = StringBuilder()
        for (rank in 8 downTo 1) {
            var empty = 0
            for (file in 0..7) {
                val r = if (!flipped) 8 - rank else rank - 1
                val c = if (!flipped) file else 7 - file
                val p = grid[r][c]
                if (p == ' ') empty++ else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(p)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 1) sb.append('/')
        }
        val placement = sb.toString()
        if (placement.count { it == 'K' } != 1 || placement.count { it == 'k' } != 1) return null
        if (placement.count { it.isUpperCase() } > 16 || placement.count { it.isLowerCase() } > 16) return null
        return placement
    }

    private fun expand(p: String): CharArray {
        val out = CharArray(64) { ' ' }
        var i = 0
        for (ch in p) {
            if (ch == '/') continue
            if (ch.isDigit()) i += ch - '0' else { if (i < 64) out[i] = ch; i++ }
        }
        return out
    }

    /**
     * Whose turn is it after the board went from oldP to newP? A side "moved" if one of its pieces
     * both left a square and arrived on one. Extra arrivals (move dots, rings) are ignored.
     */
    fun nextTurn(oldP: String, newP: String, whiteToMove: Boolean): Turn {
        val a = expand(oldP); val b = expand(newP)
        var changed = 0
        val arr = HashSet<Boolean>(); val dep = HashSet<Boolean>()
        for (i in 0 until 64) {
            if (a[i] == b[i]) continue
            changed++
            if (b[i] != ' ') arr.add(b[i].isUpperCase())
            if (a[i] != ' ') dep.add(a[i].isUpperCase())
        }
        if (changed == 0) return Turn(true, whiteToMove)
        if (changed > 6) return Turn(false, null)           // too different: probably a bad frame
        val movers = arr.intersect(dep)
        return when (movers.size) {
            1 -> Turn(true, !movers.first())                // that side just moved
            2 -> Turn(true, whiteToMove)                    // two moves happened between two reads
            else -> Turn(true, null)
        }
    }

    /** Placement + side to move -> full FEN. Castling rights are guessed from piece positions. */
    fun fullFen(placement: String, whiteToMove: Boolean): String {
        val rows = placement.split('/')   // rows[0] = rank 8 ... rows[7] = rank 1
        fun expandRow(s: String) = buildString {
            for (ch in s) if (ch.isDigit()) repeat(ch - '0') { append('.') } else append(ch)
        }
        val r8 = expandRow(rows[0]); val r1 = expandRow(rows[7])
        val cs = StringBuilder()
        if (r1[4] == 'K' && r1[7] == 'R') cs.append('K')
        if (r1[4] == 'K' && r1[0] == 'R') cs.append('Q')
        if (r8[4] == 'k' && r8[7] == 'r') cs.append('k')
        if (r8[4] == 'k' && r8[0] == 'r') cs.append('q')
        return "$placement ${if (whiteToMove) "w" else "b"} ${if (cs.isEmpty()) "-" else cs} - 0 1"
    }

    /** Screen-pixel centre of a square like "e4". */
    fun center(sq: String): PointF {
        val file = sq[0] - 'a'
        val rank = sq[1] - '1' + 1
        val col = if (!flipped) file else 7 - file
        val row = if (!flipped) 8 - rank else rank - 1
        return PointF(
            board.left + (col + 0.5f) * board.width() / 8f,
            board.top + (row + 0.5f) * board.height() / 8f
        )
    }
}
