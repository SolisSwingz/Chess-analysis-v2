package com.example.chessarrows

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }
        col.addView(TextView(this).apply {
            textSize = 17f
            text = "Chess Arrows (for bot games and analysis)\n\n" +
                "1. Allow draw-over-apps\n" +
                "2. Start, then approve screen capture\n" +
                "3. Open Chess.com and start a bot game (starting position)\n" +
                "4. Pull down notifications, tap Calibrate board, then tap the board's top-left and bottom-right corners\n\n" +
                "Deselect pieces before the arrow updates. Recalibrate for each new game."
        })
        fun btn(t: String, f: () -> Unit) =
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Allow draw-over-apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Start") { start() }
        btn("Stop") { stopService(Intent(this, CaptureService::class.java)) }
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow draw-over-apps first", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1); return
        }
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Without notifications you can't reach the Calibrate button", Toast.LENGTH_LONG).show()
        askCapture()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data)
            )
            Toast.makeText(this, "Running. Open Chess.com, then calibrate from the notification.", Toast.LENGTH_LONG).show()
        }
    }
}
