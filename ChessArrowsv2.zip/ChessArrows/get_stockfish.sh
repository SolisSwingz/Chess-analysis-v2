#!/usr/bin/env bash
# Downloads the official Stockfish Android (arm64) build and drops it where the app expects it.
set -e
URL=https://github.com/official-stockfish/Stockfish/releases/download/sf_19/stockfish-android-arm64-universal.tar.gz
tmp=$(mktemp -d)
curl -L "$URL" | tar -xz -C "$tmp"
mkdir -p app/src/main/jniLibs/arm64-v8a
cp "$tmp/stockfish/stockfish-android-arm64-universal" app/src/main/jniLibs/arm64-v8a/libstockfish.so
echo "Stockfish installed."
